# Command Center

## Editing:
Add commands to wrapper.sh "commands array" 
Some sample commands have already been added:

`commands=('CFG R1 "show run"' 'CFG R2 "show version"')`

## Running:
`git clone https://github.com/Internetworkexpert/INE-VIRL.git && cd INE-VIRL/RSv5.Graded.Labs/ && chmod a+x wrapper.sh && ./wrapper.sh`
